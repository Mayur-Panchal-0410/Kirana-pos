import React from 'react'
import Billing from '../components/Billing'
import AddInventory from '../components/AddInventory'
import Category from '../components/Category'
import Demo from '../components/Demo'
import Login from './Loginpage'
function Home() {
  return (
    <>
    
    {/* <Billing/> */}
    {/* <AddInventory/> */}
    {/* <Category/> */}
    {/* <Demo/> */}
    <Login/>
    </>
  )
}

export default Home

