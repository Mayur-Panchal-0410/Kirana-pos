import logo from './logo.svg';
import './App.css';
import AppRoute from './routes/route';

function App() {
  return (
    <>
    <AppRoute/>
    </>
  );
}

export default App;
